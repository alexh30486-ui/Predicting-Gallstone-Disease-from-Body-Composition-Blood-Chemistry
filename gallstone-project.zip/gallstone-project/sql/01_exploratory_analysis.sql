-- ============================================================
-- Gallstone Risk Analysis — Exploratory SQL
-- Dataset: UCI Gallstone Disease Dataset (n=319)
-- ============================================================

-- 1. Baseline prevalence and demographic split
SELECT
    gallstone_status,
    COUNT(*)                                   AS n_patients,
    ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 1) AS pct_of_total,
    ROUND(AVG(age), 1)                         AS avg_age,
    ROUND(AVG(bmi), 1)                         AS avg_bmi
FROM patients
GROUP BY gallstone_status;

-- 2. Risk stratification by BMI bucket (CTE + CASE)
-- Business-style question: "which risk band has the highest incidence rate?"
WITH bmi_buckets AS (
    SELECT
        patient_id,
        gallstone_status,
        CASE
            WHEN bmi < 18.5 THEN '1_underweight'
            WHEN bmi < 25   THEN '2_normal'
            WHEN bmi < 30   THEN '3_overweight'
            ELSE '4_obese'
        END AS bmi_band
    FROM patients
)
SELECT
    bmi_band,
    COUNT(*)                                        AS n_patients,
    SUM(gallstone_status)                            AS n_positive,
    ROUND(100.0 * SUM(gallstone_status) / COUNT(*), 1) AS positive_rate_pct
FROM bmi_buckets
GROUP BY bmi_band
ORDER BY bmi_band;

-- 3. Age-decade cohort analysis with running totals (window functions)
WITH age_cohorts AS (
    SELECT
        patient_id,
        gallstone_status,
        (age / 10) * 10 AS age_decade
    FROM patients
)
SELECT
    age_decade,
    COUNT(*)                                              AS n_patients,
    SUM(gallstone_status)                                  AS n_positive,
    ROUND(100.0 * SUM(gallstone_status) / COUNT(*), 1)     AS positive_rate_pct,
    SUM(COUNT(*)) OVER (ORDER BY age_decade)               AS running_total_patients,
    RANK() OVER (ORDER BY 1.0 * SUM(gallstone_status) / COUNT(*) DESC) AS risk_rank
FROM age_cohorts
GROUP BY age_decade
ORDER BY age_decade;

-- 4. Lab value comparison: gallstone-positive vs negative (paired aggregates)
SELECT
    'total_cholesterol' AS lab_marker,
    ROUND(AVG(CASE WHEN gallstone_status = 1 THEN total_cholesterol END), 1) AS avg_positive,
    ROUND(AVG(CASE WHEN gallstone_status = 0 THEN total_cholesterol END), 1) AS avg_negative
FROM patients
UNION ALL
SELECT
    'ldl',
    ROUND(AVG(CASE WHEN gallstone_status = 1 THEN ldl END), 1),
    ROUND(AVG(CASE WHEN gallstone_status = 0 THEN ldl END), 1)
FROM patients
UNION ALL
SELECT
    'hdl',
    ROUND(AVG(CASE WHEN gallstone_status = 1 THEN hdl END), 1),
    ROUND(AVG(CASE WHEN gallstone_status = 0 THEN hdl END), 1)
FROM patients
UNION ALL
SELECT
    'triglyceride',
    ROUND(AVG(CASE WHEN gallstone_status = 1 THEN triglyceride END), 1),
    ROUND(AVG(CASE WHEN gallstone_status = 0 THEN triglyceride END), 1)
FROM patients
UNION ALL
SELECT
    'crp',
    ROUND(AVG(CASE WHEN gallstone_status = 1 THEN crp END), 1),
    ROUND(AVG(CASE WHEN gallstone_status = 0 THEN crp END), 1)
FROM patients;

-- 5. Percentile ranking of visceral fat area within each gallstone group (window function)
SELECT
    patient_id,
    gallstone_status,
    visceral_fat_area,
    ROUND(PERCENT_RANK() OVER (
        PARTITION BY gallstone_status ORDER BY visceral_fat_area
    ), 3) AS pctile_within_group
FROM patients
ORDER BY gallstone_status, visceral_fat_area DESC
LIMIT 20;

-- 6. Comorbidity load vs gallstone rate
SELECT
    comorbidity,
    COUNT(*)                                          AS n_patients,
    SUM(gallstone_status)                              AS n_positive,
    ROUND(100.0 * SUM(gallstone_status) / COUNT(*), 1) AS positive_rate_pct
FROM patients
GROUP BY comorbidity
ORDER BY comorbidity;

-- 7. Top decile of CRP (inflammation marker) — does it skew gallstone-positive?
WITH ranked AS (
    SELECT
        patient_id,
        gallstone_status,
        crp,
        NTILE(10) OVER (ORDER BY crp) AS crp_decile
    FROM patients
)
SELECT
    crp_decile,
    COUNT(*)                                          AS n_patients,
    SUM(gallstone_status)                              AS n_positive,
    ROUND(100.0 * SUM(gallstone_status) / COUNT(*), 1) AS positive_rate_pct
FROM ranked
GROUP BY crp_decile
ORDER BY crp_decile;
