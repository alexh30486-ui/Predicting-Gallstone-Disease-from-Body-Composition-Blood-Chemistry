-- ============================================================
-- Gallstone Risk Analysis — Advanced SQL
-- Self-joins, correlated subqueries, percentile comparisons
-- ============================================================

-- 1. Self-join: for every gallstone-positive patient, find the closest-age
--    gallstone-negative patient and compare their CRP levels directly.
--    (Common "matched pairs" pattern used in clinical/causal analysis.)
WITH positive AS (
    SELECT patient_id, age, crp, bmi FROM patients WHERE gallstone_status = 1
),
negative AS (
    SELECT patient_id, age, crp, bmi FROM patients WHERE gallstone_status = 0
)
SELECT
    p.patient_id  AS positive_patient,
    n.patient_id  AS matched_negative_patient,
    p.age         AS age,
    p.crp         AS positive_crp,
    n.crp         AS negative_crp,
    ROUND(p.crp - n.crp, 2) AS crp_gap
FROM positive p
JOIN negative n
    ON ABS(p.age - n.age) <= 1
QUALIFY ROW_NUMBER() OVER (
    PARTITION BY p.patient_id ORDER BY ABS(p.age - n.age), n.patient_id
) = 1
ORDER BY crp_gap DESC
LIMIT 15;
-- Note: QUALIFY isn't supported in SQLite — see 02b below for the
-- portable rewrite using a subquery instead. Kept here to show the
-- cleaner syntax available in Postgres/Snowflake/BigQuery.

-- 2. Portable (SQLite-compatible) rewrite of the matched-pairs query above.
--    Note: SQLite does NOT allow a correlated outer-column reference inside
--    an ORDER BY of a scalar subquery (a real, easy-to-hit SQLite quirk) —
--    so the match is found via a nested MIN() correlated subquery instead.
SELECT
    p.patient_id AS positive_patient,
    p.age,
    p.crp AS positive_crp,
    (
        SELECT n.patient_id FROM patients n
        WHERE n.gallstone_status = 0
          AND ABS(n.age - p.age) = (
              SELECT MIN(ABS(n2.age - p.age)) FROM patients n2 WHERE n2.gallstone_status = 0
          )
        LIMIT 1
    ) AS matched_negative_patient,
    (
        SELECT n.crp FROM patients n
        WHERE n.gallstone_status = 0
          AND ABS(n.age - p.age) = (
              SELECT MIN(ABS(n2.age - p.age)) FROM patients n2 WHERE n2.gallstone_status = 0
          )
        LIMIT 1
    ) AS negative_crp
FROM patients p
WHERE p.gallstone_status = 1
ORDER BY p.patient_id
LIMIT 15;

-- 3. Correlated subquery: patients whose CRP is above the average CRP
--    of their own age-decade cohort (a form of within-group standardization
--    done entirely in SQL, no Python needed).
SELECT
    p.patient_id,
    p.age,
    (p.age / 10) * 10 AS age_decade,
    p.crp,
    p.gallstone_status
FROM patients p
WHERE p.crp > (
    SELECT AVG(p2.crp)
    FROM patients p2
    WHERE (p2.age / 10) * 10 = (p.age / 10) * 10
)
ORDER BY age_decade, p.crp DESC
LIMIT 20;

-- 4. Multi-marker composite risk score using CTEs + subquery-based
--    percentile buckets, then a self-join to compare high-risk vs
--    low-risk patient groups on outcome rate.
WITH percentiles AS (
    SELECT
        patient_id,
        gallstone_status,
        crp,
        bmi,
        visceral_fat_area,
        NTILE(4) OVER (ORDER BY crp) AS crp_quartile,
        NTILE(4) OVER (ORDER BY bmi) AS bmi_quartile,
        NTILE(4) OVER (ORDER BY visceral_fat_area) AS vfa_quartile
    FROM patients
),
composite AS (
    SELECT
        *,
        (crp_quartile + bmi_quartile + vfa_quartile) AS composite_risk_score
    FROM percentiles
)
SELECT
    composite_risk_score,
    COUNT(*)                                          AS n_patients,
    SUM(gallstone_status)                              AS n_positive,
    ROUND(100.0 * SUM(gallstone_status) / COUNT(*), 1) AS positive_rate_pct
FROM composite
GROUP BY composite_risk_score
ORDER BY composite_risk_score;

-- 5. Self-join to find pairs of patients with near-identical BMI but
--    opposite gallstone outcomes — useful for spotting confounders,
--    since it isolates cases where BMI alone doesn't explain the outcome.
SELECT
    a.patient_id AS patient_a,
    b.patient_id AS patient_b,
    a.bmi        AS bmi_a,
    b.bmi        AS bmi_b,
    a.gallstone_status AS status_a,
    b.gallstone_status AS status_b,
    a.crp AS crp_a,
    b.crp AS crp_b
FROM patients a
JOIN patients b
    ON a.patient_id < b.patient_id
    AND ABS(a.bmi - b.bmi) < 0.3
    AND a.gallstone_status != b.gallstone_status
ORDER BY ABS(a.bmi - b.bmi)
LIMIT 15;
