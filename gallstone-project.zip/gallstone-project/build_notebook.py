"""
Generates gallstone_analysis.ipynb — a single, self-contained,
Colab-runnable notebook that narrates the whole project:
data cleaning -> SQLite -> SQL analysis -> modeling -> tuning -> SHAP.

Run once locally: python3 build_notebook.py
"""
import nbformat as nbf

nb = nbf.v4.new_notebook()
cells = []

def md(text):
    cells.append(nbf.v4.new_markdown_cell(text))

def code(text):
    cells.append(nbf.v4.new_code_cell(text))

# ------------------------------------------------------------------
md("""# Predicting Gallstone Disease from Body Composition & Blood Chemistry

**Author:** Alex Hernandez
**Dataset:** UCI Machine Learning Repository — Gallstone Disease Dataset (n=319)

This notebook is the full, runnable version of the project in this repo:
raw clinical data -> SQLite database -> SQL risk analysis (window functions,
CTEs, correlated subqueries) -> ML classification -> hyperparameter tuning
-> SHAP explainability.

> Open this in Google Colab via:
> `https://colab.research.google.com/github/<your-username>/<your-repo>/blob/main/gallstone_analysis.ipynb`
""")

code("""# If running in Colab, clone the repo to get the raw data + SQL files.
# (Skip this cell if you're running locally from inside the repo already.)
import os
if not os.path.exists('data/raw/gallstone_patients.csv'):
    !git clone https://github.com/<your-username>/<your-repo>.git repo_clone
    %cd repo_clone
""")

code("""!pip install -q pandas scikit-learn matplotlib shap""")

# ------------------------------------------------------------------
md("## 1. Load & inspect the data")

code("""import pandas as pd
import sqlite3

df = pd.read_csv('data/raw/gallstone_patients.csv')
print(df.shape)
df.head()
""")

code("""df['gallstone_status'].value_counts()""")

# ------------------------------------------------------------------
md("""## 2. Build the SQLite database

Loading into a real relational database (rather than just pandas) so the
analysis below is done in actual SQL — the skill this project is meant to
demonstrate.""")

code("""conn = sqlite3.connect('gallstone_analysis.db')
df.to_sql('patients', conn, if_exists='replace', index=False)
conn.execute('CREATE INDEX IF NOT EXISTS idx_gallstone_status ON patients(gallstone_status);')
conn.commit()
pd.read_sql('SELECT COUNT(*) AS n_rows FROM patients', conn)
""")

# ------------------------------------------------------------------
md("""## 3. SQL exploratory analysis

### 3.1 Baseline prevalence""")

code("""pd.read_sql('''
SELECT
    gallstone_status,
    COUNT(*) AS n_patients,
    ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 1) AS pct_of_total,
    ROUND(AVG(age), 1) AS avg_age,
    ROUND(AVG(bmi), 1) AS avg_bmi
FROM patients
GROUP BY gallstone_status;
''', conn)
""")

md("### 3.2 Risk stratification by BMI band")

code("""pd.read_sql('''
WITH bmi_buckets AS (
    SELECT
        patient_id,
        gallstone_status,
        CASE
            WHEN bmi < 18.5 THEN '1_underweight'
            WHEN bmi < 25   THEN '2_normal'
            WHEN bmi < 30   THEN '3_overweight'
            ELSE '4_obese'
        END AS bmi_band
    FROM patients
)
SELECT
    bmi_band,
    COUNT(*) AS n_patients,
    SUM(gallstone_status) AS n_positive,
    ROUND(100.0 * SUM(gallstone_status) / COUNT(*), 1) AS positive_rate_pct
FROM bmi_buckets
GROUP BY bmi_band
ORDER BY bmi_band;
''', conn)
""")

md("### 3.3 Age-decade cohort analysis (window functions)")

code("""pd.read_sql('''
WITH age_cohorts AS (
    SELECT patient_id, gallstone_status, (age / 10) * 10 AS age_decade
    FROM patients
)
SELECT
    age_decade,
    COUNT(*) AS n_patients,
    SUM(gallstone_status) AS n_positive,
    ROUND(100.0 * SUM(gallstone_status) / COUNT(*), 1) AS positive_rate_pct,
    SUM(COUNT(*)) OVER (ORDER BY age_decade) AS running_total_patients,
    RANK() OVER (ORDER BY 1.0 * SUM(gallstone_status) / COUNT(*) DESC) AS risk_rank
FROM age_cohorts
GROUP BY age_decade
ORDER BY age_decade;
''', conn)
""")

md("""### 3.4 CRP deciles — the standout finding

Splitting patients into 10 equal-sized CRP (inflammation marker) groups
and checking gallstone rate per group.""")

code("""pd.read_sql('''
WITH ranked AS (
    SELECT patient_id, gallstone_status, crp,
           NTILE(10) OVER (ORDER BY crp) AS crp_decile
    FROM patients
)
SELECT
    crp_decile,
    COUNT(*) AS n_patients,
    SUM(gallstone_status) AS n_positive,
    ROUND(100.0 * SUM(gallstone_status) / COUNT(*), 1) AS positive_rate_pct
FROM ranked
GROUP BY crp_decile
ORDER BY crp_decile;
''', conn)
""")

md("""**Takeaway:** the positive rate climbs sharply in the top CRP deciles —
inflammation tracks with gallstone risk more strongly than most people
would guess before looking at the data.""")

# ------------------------------------------------------------------
md("""## 4. Correlated subquery example

Patients whose CRP is above the average for their own age-decade —
standardizing within-cohort entirely in SQL.""")

code("""pd.read_sql('''
SELECT
    p.patient_id, p.age, (p.age / 10) * 10 AS age_decade,
    p.crp, p.gallstone_status
FROM patients p
WHERE p.crp > (
    SELECT AVG(p2.crp) FROM patients p2
    WHERE (p2.age / 10) * 10 = (p.age / 10) * 10
)
ORDER BY age_decade, p.crp DESC
LIMIT 10;
''', conn)
""")

# ------------------------------------------------------------------
md("## 5. Machine learning: baseline model comparison")

code("""from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score, classification_report
import matplotlib.pyplot as plt

y = df['gallstone_status']
X = df.drop(columns=['gallstone_status', 'patient_id'])

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, stratify=y, random_state=42
)

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

models = {
    'Logistic Regression': LogisticRegression(max_iter=2000, random_state=42),
    'Random Forest': RandomForestClassifier(n_estimators=300, random_state=42),
    'Gradient Boosting': GradientBoostingClassifier(random_state=42),
}

cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
results = {}
for name, model in models.items():
    Xtr, Xte = (X_train_scaled, X_test_scaled) if name == 'Logistic Regression' else (X_train, X_test)
    scores = cross_val_score(model, Xtr, y_train, cv=cv, scoring='roc_auc')
    model.fit(Xtr, y_train)
    test_auc = roc_auc_score(y_test, model.predict_proba(Xte)[:, 1])
    results[name] = {'cv_auc_mean': scores.mean(), 'test_auc': test_auc}
    print(f"{name}: CV AUC={scores.mean():.3f}  Test AUC={test_auc:.3f}")

pd.DataFrame(results).T
""")

# ------------------------------------------------------------------
md("## 6. Hyperparameter tuning (Random Forest)")

code("""from sklearn.model_selection import GridSearchCV

param_grid = {
    'n_estimators': [200, 400],
    'max_depth': [None, 8],
    'min_samples_leaf': [1, 4],
}

search = GridSearchCV(
    RandomForestClassifier(random_state=42), param_grid,
    scoring='roc_auc', cv=cv, n_jobs=-1
)
search.fit(X_train, y_train)

best_model = search.best_estimator_
test_auc = roc_auc_score(y_test, best_model.predict_proba(X_test)[:, 1])
print('Best CV AUC:', round(search.best_score_, 3))
print('Best params:', search.best_params_)
print('Tuned test AUC:', round(test_auc, 3))
""")

# ------------------------------------------------------------------
md("""## 7. SHAP explainability

Global feature importance is a start — SHAP explains *why* the model
flagged each individual patient, which is what actually matters in a
clinical or product context.""")

code("""import shap

explainer = shap.TreeExplainer(best_model)
shap_values = explainer.shap_values(X_test)

if isinstance(shap_values, list):
    sv_positive = shap_values[1]
elif shap_values.ndim == 3:
    sv_positive = shap_values[:, :, 1]
else:
    sv_positive = shap_values

shap.summary_plot(sv_positive, X_test)
""")

code("""# Explain one specific high-confidence prediction
import numpy as np

proba = best_model.predict_proba(X_test)[:, 1]
preds = best_model.predict(X_test)
mask = (y_test.values == 1) & (preds == 1)
idx = np.argmax(np.where(mask, proba, -1))

patient_shap = sv_positive[idx]
top = pd.Series(patient_shap, index=X.columns).abs().sort_values(ascending=False).head(8).index
pd.DataFrame({
    'feature': top,
    'patient_value': X_test.iloc[idx][top].values,
    'shap_contribution': pd.Series(patient_shap, index=X.columns)[top].values,
}).sort_values('shap_contribution', key=abs, ascending=False)
""")

md("""## 8. Conclusions

- Baseline prevalence is well-balanced (49.5% positive), so accuracy isn't
  misleading here.
- **CRP (inflammation marker) and Vitamin D are the strongest predictors**,
  ahead of BMI and cholesterol — a more interesting story than
  "obesity causes gallstones."
- Tuned Random Forest reaches ~0.89 test ROC-AUC.
- SHAP shows the model's reasoning is patient-specific, not just a single
  global rule — useful context for any real deployment discussion.

### Possible extensions
- Migrate SQLite -> Postgres, containerize with Docker
- Build a small Streamlit app where a recruiter can enter values and see
  a live risk score + SHAP explanation
- Add CI (GitHub Actions) that re-runs the pipeline on every push
""")

nb['cells'] = cells

with open('gallstone_analysis.ipynb', 'w') as f:
    nbf.write(nb, f)

print("Wrote gallstone_analysis.ipynb")
