"""
Trains the final tuned Random Forest on the FULL dataset (all 319 patients —
not just the train split, since this is the model that ships in the app)
and saves it, along with feature medians for sensible slider defaults.

Run: python3 scripts/train_final_model.py
"""
import sqlite3
import json
import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier

DB_PATH = "data/gallstone.db"

# Best params found via GridSearchCV in tune_and_explain.py
BEST_PARAMS = {"n_estimators": 200, "max_depth": 8, "min_samples_leaf": 1}


def main():
    conn = sqlite3.connect(DB_PATH)
    df = pd.read_sql("SELECT * FROM patients", conn)
    conn.close()

    y = df["gallstone_status"]
    X = df.drop(columns=["gallstone_status", "patient_id"])

    model = RandomForestClassifier(random_state=42, **BEST_PARAMS)
    model.fit(X, y)

    joblib.dump(model, "app_model.joblib")
    print("Saved app_model.joblib")

    feature_info = {
        "feature_order": list(X.columns),
        "medians": X.median().to_dict(),
        "mins": X.min().to_dict(),
        "maxs": X.max().to_dict(),
    }
    with open("app_feature_info.json", "w") as f:
        json.dump(feature_info, f, indent=2)
    print("Saved app_feature_info.json")


if __name__ == "__main__":
    main()
