"""
Gallstone Risk Prediction — Hyperparameter Tuning & Explainability
Tunes the best-performing model from model.py with GridSearchCV, then
uses SHAP to explain predictions at both the global and individual-patient
level (not just "feature importance," but *why* each patient scored high).

Run: python3 scripts/tune_and_explain.py
"""
import sqlite3
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import shap

from sklearn.model_selection import train_test_split, GridSearchCV, StratifiedKFold
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score, classification_report

DB_PATH = "data/gallstone.db"
RANDOM_STATE = 42


def load_data():
    conn = sqlite3.connect(DB_PATH)
    df = pd.read_sql("SELECT * FROM patients", conn)
    conn.close()
    return df


def main():
    df = load_data()
    y = df["gallstone_status"]
    X = df.drop(columns=["gallstone_status", "patient_id"])

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, stratify=y, random_state=RANDOM_STATE
    )

    # ---- Hyperparameter tuning ----
    # Kept intentionally compact: this environment has a single CPU core,
    # so a wide grid (e.g. 200+ combos x 5 folds x 600 trees) would take
    # far too long. In a normal multi-core setup this grid could be widened.
    param_grid = {
        "n_estimators": [200, 400],
        "max_depth": [None, 8],
        "min_samples_leaf": [1, 4],
    }

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    base_model = RandomForestClassifier(random_state=RANDOM_STATE, n_jobs=1)

    search = GridSearchCV(
        base_model, param_grid, scoring="roc_auc", cv=cv, n_jobs=1, verbose=1
    )
    search.fit(X_train, y_train)

    print("=" * 60)
    print("HYPERPARAMETER TUNING RESULTS")
    print("=" * 60)
    print(f"Best CV ROC-AUC: {search.best_score_:.3f}")
    print(f"Best params: {search.best_params_}")

    best_model = search.best_estimator_
    test_auc = roc_auc_score(y_test, best_model.predict_proba(X_test)[:, 1])
    print(f"Tuned model — Test ROC-AUC: {test_auc:.3f}")
    print(classification_report(y_test, best_model.predict(X_test),
                                 target_names=["No Gallstone", "Gallstone"]))

    pd.DataFrame(search.cv_results_).to_csv("outputs/gridsearch_results.csv", index=False)
    print("Saved outputs/gridsearch_results.csv")

    # ---- SHAP explainability ----
    print("\nComputing SHAP values...")
    explainer = shap.TreeExplainer(best_model)
    shap_values = explainer.shap_values(X_test)

    # For binary classifiers, shap_values can be a list [class0, class1] or a 3D array
    if isinstance(shap_values, list):
        sv_positive = shap_values[1]
    elif shap_values.ndim == 3:
        sv_positive = shap_values[:, :, 1]
    else:
        sv_positive = shap_values

    # Global summary plot (beeswarm)
    plt.figure(figsize=(9, 7))
    shap.summary_plot(sv_positive, X_test, show=False)
    plt.tight_layout()
    plt.savefig("outputs/shap_summary.png", dpi=150, bbox_inches="tight")
    plt.close()
    print("Saved outputs/shap_summary.png")

    # Individual patient explanation — pick the highest-confidence
    # correctly-classified positive case as a concrete talking point
    proba = best_model.predict_proba(X_test)[:, 1]
    preds = best_model.predict(X_test)
    correct_positive_mask = (y_test.values == 1) & (preds == 1)
    if correct_positive_mask.any():
        idx = np.argmax(np.where(correct_positive_mask, proba, -1))
        patient_row = X_test.iloc[[idx]]
        patient_shap = sv_positive[idx]

        top_features = pd.Series(patient_shap, index=X.columns).abs().sort_values(ascending=False).head(8).index
        contributions = pd.DataFrame({
            "feature": top_features,
            "patient_value": patient_row[top_features].values[0],
            "shap_contribution": pd.Series(patient_shap, index=X.columns)[top_features].values,
        }).sort_values("shap_contribution", key=abs, ascending=False)

        contributions.to_csv("outputs/example_patient_explanation.csv", index=False)
        print("\nExample: why the model flagged one specific high-confidence patient")
        print(f"(Predicted probability of gallstone: {proba[idx]:.3f})")
        print(contributions.to_string(index=False))
        print("Saved outputs/example_patient_explanation.csv")

    # Save final tuned model results summary
    summary = pd.DataFrame([{
        "best_cv_auc": search.best_score_,
        "test_auc": test_auc,
        "best_params": str(search.best_params_),
    }])
    summary.to_csv("outputs/tuned_model_summary.csv", index=False)
    print("\nSaved outputs/tuned_model_summary.csv")


if __name__ == "__main__":
    main()
