"""
Gallstone Risk Prediction — Modeling Pipeline
Loads cleaned patient data from SQLite, trains baseline + tree-based
classifiers, and evaluates them with cross-validation.

Run: python3 scripts/model.py
"""
import sqlite3
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    roc_auc_score, classification_report, confusion_matrix,
    RocCurveDisplay
)

DB_PATH = "data/gallstone.db"
RANDOM_STATE = 42


def load_data():
    conn = sqlite3.connect(DB_PATH)
    df = pd.read_sql("SELECT * FROM patients", conn)
    conn.close()
    return df


def main():
    df = load_data()
    y = df["gallstone_status"]
    X = df.drop(columns=["gallstone_status", "patient_id"])

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, stratify=y, random_state=RANDOM_STATE
    )

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    models = {
        "Logistic Regression": LogisticRegression(max_iter=2000, random_state=RANDOM_STATE),
        "Random Forest": RandomForestClassifier(n_estimators=300, random_state=RANDOM_STATE),
        "Gradient Boosting": GradientBoostingClassifier(random_state=RANDOM_STATE),
    }

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    results = {}

    print("=" * 60)
    print("MODEL COMPARISON (5-fold CV, ROC-AUC)")
    print("=" * 60)

    fig, ax = plt.subplots(figsize=(7, 6))

    for name, model in models.items():
        if name == "Logistic Regression":
            cv_scores = cross_val_score(model, X_train_scaled, y_train, cv=cv, scoring="roc_auc")
            model.fit(X_train_scaled, y_train)
            test_auc = roc_auc_score(y_test, model.predict_proba(X_test_scaled)[:, 1])
            RocCurveDisplay.from_estimator(model, X_test_scaled, y_test, ax=ax, name=name)
            preds = model.predict(X_test_scaled)
        else:
            cv_scores = cross_val_score(model, X_train, y_train, cv=cv, scoring="roc_auc")
            model.fit(X_train, y_train)
            test_auc = roc_auc_score(y_test, model.predict_proba(X_test)[:, 1])
            RocCurveDisplay.from_estimator(model, X_test, y_test, ax=ax, name=name)
            preds = model.predict(X_test)

        results[name] = {"cv_auc_mean": cv_scores.mean(), "cv_auc_std": cv_scores.std(), "test_auc": test_auc}
        print(f"\n{name}")
        print(f"  CV ROC-AUC: {cv_scores.mean():.3f} (+/- {cv_scores.std():.3f})")
        print(f"  Test ROC-AUC: {test_auc:.3f}")
        print(classification_report(y_test, preds, target_names=["No Gallstone", "Gallstone"]))

    ax.plot([0, 1], [0, 1], linestyle="--", color="gray", label="Chance")
    ax.set_title("ROC Curves — Gallstone Prediction Models")
    ax.legend()
    plt.tight_layout()
    plt.savefig("outputs/roc_curves.png", dpi=150)
    print("\nSaved outputs/roc_curves.png")

    # Feature importance from the best tree-based model
    best_tree_name = max(
        [n for n in models if n != "Logistic Regression"],
        key=lambda n: results[n]["test_auc"]
    )
    best_model = models[best_tree_name]
    importances = pd.Series(best_model.feature_importances_, index=X.columns).sort_values(ascending=False).head(15)

    plt.figure(figsize=(8, 6))
    importances.sort_values().plot(kind="barh")
    plt.title(f"Top 15 Feature Importances ({best_tree_name})")
    plt.xlabel("Importance")
    plt.tight_layout()
    plt.savefig("outputs/feature_importance.png", dpi=150)
    print("Saved outputs/feature_importance.png")

    # Save a results summary
    summary = pd.DataFrame(results).T
    summary.to_csv("outputs/model_results.csv")
    print("\nSaved outputs/model_results.csv")
    print("\nTop 10 features driving predictions:")
    print(importances.sort_values(ascending=False).head(10).to_string())


if __name__ == "__main__":
    main()
